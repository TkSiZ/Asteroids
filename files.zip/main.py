# ASTEROIDES v2.0
from game import Game

if __name__ == "__main__":
    Game().run()
